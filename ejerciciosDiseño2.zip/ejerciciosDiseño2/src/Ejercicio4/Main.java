package Ejercicio4;

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        String tipoPersona = JOptionPane.showInputDialog("Ingrese el tipo de persona (estudiante, profesor, personal de servicio):");

        String nombre = JOptionPane.showInputDialog("Ingrese el nombre:");
        String apellidos = JOptionPane.showInputDialog("Ingrese los apellidos:");
        String identificacion = JOptionPane.showInputDialog("Ingrese la identificación:");
        String estadoCivil = JOptionPane.showInputDialog("Ingrese el estado civil:");
        int anioIncorporacion;
        int numeroDespacho;

        switch (tipoPersona.toLowerCase()) {
            case "estudiante" -> {
                String curso = JOptionPane.showInputDialog("Ingrese el curso:");
                Estudiante estudiante = new Estudiante(nombre, apellidos, identificacion, estadoCivil, curso);
                BaseDeDatos.registrarPersonaEnBD(estudiante, "Estudiante");
            }

            case "profesor" -> {
                anioIncorporacion = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el año de incorporación:"));
                numeroDespacho = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de despacho:"));
                String departamento = JOptionPane.showInputDialog("Ingrese el departamento:");
                Profesor profesor = new Profesor(nombre, apellidos, identificacion, estadoCivil, anioIncorporacion, numeroDespacho, departamento);
                BaseDeDatos.registrarPersonaEnBD(profesor, "Profesor");
            }

            case "personal de servicio" -> {
                anioIncorporacion = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el año de incorporación:"));
                numeroDespacho = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de despacho:"));
                String seccion = JOptionPane.showInputDialog("Ingrese la sección:");
                PersonalServicio personalServicio = new PersonalServicio(nombre, apellidos, identificacion, estadoCivil, anioIncorporacion, numeroDespacho, seccion);
                BaseDeDatos.registrarPersonaEnBD(personalServicio, "Personal de Servicio");
            }

            default -> JOptionPane.showMessageDialog(null, "Tipo de persona no reconocido.");
        }
    }
}
