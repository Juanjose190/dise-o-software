package Ejercicio4;


public class PersonalServicio extends Empleado {

    private String seccion;

    public PersonalServicio(String nombre, String apellidos, String identificacion, String estadoCivil, int anioIncorporacion, int numeroDespacho, String seccion) {
        super(nombre, apellidos, identificacion, estadoCivil, anioIncorporacion, numeroDespacho);
        this.seccion = seccion;
    }

    public String getSeccion() {
        return seccion;
    }

    public void setSeccion(String seccion) {
        this.seccion = seccion;
    }

    @Override
    public void imprimirInformacion() {
        super.imprimirInformacion();
        System.out.println("Sección: " + seccion);
    }
}
