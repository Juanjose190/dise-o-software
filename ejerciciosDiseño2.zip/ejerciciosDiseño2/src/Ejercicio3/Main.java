package Ejercicio3;


import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
       String[] opciones = {"Empleado", "Secretario", "Vendedor", "JefeDeZona"};
        String opcion = (String) JOptionPane.showInputDialog(null, "Elige una figura:",
                "Selector de Figuras", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

            switch (opcion) {
                case "Empleado":
                    Empleado empleado = Empleado.crearEmpleado();
                    empleado.imprimirDatos();
                    break;
                case "Secretario":
                    Secretario secretario = Secretario.crearSecretario();
                    secretario.imprimirDatos();
                    break;
                case "Vendedor":
                    Vendedor vendedor = Vendedor.crearVendedor();
                    vendedor.imprimirDatos();
                    break;
                case "JefeDeZona":
                    JefeDeZona jefeDeZona = JefeDeZona.crearJefeDeZona();
                    jefeDeZona.imprimirDatos();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Intente de nuevo.");
            }
        } 
    }

