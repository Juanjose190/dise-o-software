package Ejercicio3;


import javax.swing.JOptionPane;

public class JefeDeZona extends Empleado {

    private Secretario secretario;
    private String cocheEmpresa;

    public JefeDeZona(String nombre, String apellidos, String dni, String direccion, String telefono, double salario, int antiguedad, String cocheEmpresa, Secretario secretario) {
        super(nombre, apellidos, dni, direccion, telefono, salario, antiguedad);
        this.secretario = secretario;
        this.cocheEmpresa = cocheEmpresa;
    }

    @Override
    public void incrementarSalario(double porcentaje) {
        super.incrementarSalario(20); // Aumento del 20% para el jefe de zona
    }

    @Override
    public void imprimirDatos() {
        super.imprimirDatos();
        JOptionPane.showMessageDialog(null, "Coche de Empresa: " + cocheEmpresa
                + "\nSecretario a cargo: " + secretario.nombre + " " + secretario.apellidos);
    }

    public static JefeDeZona crearJefeDeZona() {
        Empleado baseEmpleado = Empleado.crearEmpleado();
        Secretario secretario = Secretario.crearSecretario();
        String cocheEmpresa = JOptionPane.showInputDialog("Ingrese el coche de la empresa (matrícula, marca, modelo):");
        return new JefeDeZona(baseEmpleado.nombre, baseEmpleado.apellidos, baseEmpleado.dni,
                baseEmpleado.direccion, baseEmpleado.telefono,
                baseEmpleado.salario, baseEmpleado.antiguedad, cocheEmpresa, secretario);
    }
}
