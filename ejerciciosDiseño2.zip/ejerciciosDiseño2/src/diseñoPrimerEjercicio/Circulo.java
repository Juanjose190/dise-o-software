/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package diseñoPrimerEjercicio;

/**
 *
 * @author JUAN JOSE
 */
public class Circulo extends FigurasGeometricas {

    public Circulo(int radio) {
        super(radio);
    }

    @Override
    public double getArea() {
        return Math.PI * valor1 * valor1;
    }

    @Override
    public double getPerimetro() {
        return 2 * Math.PI * valor1;
    }
}
