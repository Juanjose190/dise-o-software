/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package diseñoPrimerEjercicio;

/**
 *
 * @author JUAN JOSE
 */
public class Cuadrado extends FigurasGeometricas {

    public Cuadrado(int lado) {
        super(lado);
    }

    @Override
    public double getArea() {
        return valor1 * valor1;
    }

    @Override
    public double getPerimetro() {
        return 4 * valor1;
    }
}
