/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package diseñoPrimerEjercicio;

/**
 *
 * @author JUAN JOSE
 */
import javax.swing.JOptionPane;

public class EjerciciosDiseño2 {

    public static void main(String[] args) {
        String[] opciones = {"Círculo", "Cuadrado", "Rectángulo", "Triángulo", "Cubo"};
        String opcion = (String) JOptionPane.showInputDialog(null, "Elige una figura:",
                "Selector de Figuras", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

        switch (opcion) {
            case "Círculo":
                int radio = Integer.parseInt(JOptionPane.showInputDialog("Introduce el radio del círculo:"));
                Circulo circulo = new Circulo(radio);
                mostrarResultados(circulo);
                break;

            case "Cuadrado":
                int lado = Integer.parseInt(JOptionPane.showInputDialog("Introduce el lado del cuadrado:"));
                Cuadrado cuadrado = new Cuadrado(lado);
                mostrarResultados(cuadrado);
                break;

            case "Rectángulo":
                int largo = Integer.parseInt(JOptionPane.showInputDialog("Introduce el largo del rectángulo:"));
                int ancho = Integer.parseInt(JOptionPane.showInputDialog("Introduce el ancho del rectángulo:"));
                Rectangulo rectangulo = new Rectangulo(largo, ancho);
                mostrarResultados(rectangulo);
                break;

            case "Triángulo":
                int base = Integer.parseInt(JOptionPane.showInputDialog("Introduce la base del triángulo:"));
                int altura = Integer.parseInt(JOptionPane.showInputDialog("Introduce la altura del triángulo:"));
                Triangulo triangulo = new Triangulo(base, altura);
                mostrarResultados(triangulo);
                break;

            case "Cubo":
                int ladoCubo = Integer.parseInt(JOptionPane.showInputDialog("Introduce el lado del cubo:"));
                Cubo cubo = new Cubo(ladoCubo);
                JOptionPane.showMessageDialog(null, "Área del cubo: " + cubo.getArea());
                break;

            default:
                JOptionPane.showMessageDialog(null, "Opción no válida");
                break;
        }
    }

    public static void mostrarResultados(FigurasGeometricas figura) {
        JOptionPane.showMessageDialog(null, "Área: " + figura.getArea()
                + "\nPerímetro: " + figura.getPerimetro());
    }
}
