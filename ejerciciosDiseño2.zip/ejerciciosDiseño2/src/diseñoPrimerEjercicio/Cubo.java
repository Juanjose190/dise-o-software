/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package diseñoPrimerEjercicio;

/**
 *
 * @author JUAN JOSE
 */
public class Cubo extends Cuadrado {

    public Cubo(int lado) {
        super(lado);
    }

    @Override
    public double getArea() {
        return 6 * super.getArea();
    }
}
