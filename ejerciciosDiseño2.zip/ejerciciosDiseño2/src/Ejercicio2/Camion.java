/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio2;

import javax.swing.JOptionPane;

/**
 *
 * @author JUAN JOSE
 */
public class Camion extends Vehiculo {

    private Remolque remolque;

    public Camion(String matricula) {
        super(matricula);
        this.remolque = null; 
    }

    public void ponRemolque(Remolque remolque) {
        this.remolque = remolque;
    }

    public void quitaRemolque() {
        this.remolque = null;
    }

    @Override
    public void acelerar(double kmh) {
        super.acelerar(kmh);
        if (remolque != null && velocidad > 100) {
            JOptionPane.showMessageDialog(null, "El camión con remolque va demasiado reapido");
        }
    }

    @Override
    public String toString() {
        String info = super.toString();
        if (remolque != null) {
            info += ", " + remolque.toString();
        }
        return info;
    }
}
