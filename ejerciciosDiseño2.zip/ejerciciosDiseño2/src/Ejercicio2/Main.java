/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio2;

/**
 *
 * @author JUAN JOSE
 */
import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {

        String matriculaCoche = JOptionPane.showInputDialog("Ingrese la placa del carro:");
        int numeroPuertas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de puertas del coche:"));
        Carro coche = new Carro(matriculaCoche, numeroPuertas);
        JOptionPane.showMessageDialog(null, coche.toString());

        double acelerarCoche = Double.parseDouble(JOptionPane.showInputDialog("Cuántos km/h desea acelerar el carro?"));
        coche.acelerar(acelerarCoche);
        JOptionPane.showMessageDialog(null, coche.toString());

        String matriculaCamion = JOptionPane.showInputDialog("Ingrese la placa del camión:");
        Camion camion = new Camion(matriculaCamion);
        JOptionPane.showMessageDialog(null, camion.toString());

        double acelerarCamion = Double.parseDouble(JOptionPane.showInputDialog("Cuántos km/h desea acelerar el camión?"));
        camion.acelerar(acelerarCamion);
        JOptionPane.showMessageDialog(null, camion.toString());

        int pesoRemolque = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el peso del remolque en kilos:"));
        Remolque remolque = new Remolque(pesoRemolque);
        camion.ponRemolque(remolque);
        JOptionPane.showMessageDialog(null, camion.toString());

        double acelerarConRemolque = Double.parseDouble(JOptionPane.showInputDialog("Cuántos km/h desea acelerar el camión con remolque?"));
        camion.acelerar(acelerarConRemolque);
        JOptionPane.showMessageDialog(null, camion.toString());
    }
}
