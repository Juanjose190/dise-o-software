/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio4;

/**
 *
 * @author JUAN JOSE
 */
public class Dog extends Mammal {
    public Dog(String name) {
        super(name);
    }

 
    @Override
    public String toString() {
        return "Dog: " + super.toString();
    }
}
