package Ejercicio3;


import javax.swing.JOptionPane;

public class Secretario extends Empleado {

    private String numeroFax;

    public Secretario(String nombre, String apellidos, String dni, String direccion, String telefono, double salario, int antiguedad, String numeroFax) {
        super(nombre, apellidos, dni, direccion, telefono, salario, antiguedad);
        this.numeroFax = numeroFax;
    }

    @Override
    public void incrementarSalario(double porcentaje) {
        super.incrementarSalario(5); // Aumento del 5% para el secretario
    }

    @Override
    public void imprimirDatos() {
        super.imprimirDatos();
        JOptionPane.showMessageDialog(null, "Número de Fax: " + numeroFax);
    }

    public static Secretario crearSecretario() {
        Empleado baseEmpleado = Empleado.crearEmpleado();
        String numeroFax = JOptionPane.showInputDialog("Ingrese el número de fax del secretario:");
        return new Secretario(baseEmpleado.nombre, baseEmpleado.apellidos, baseEmpleado.dni,
                baseEmpleado.direccion, baseEmpleado.telefono,
                baseEmpleado.salario, baseEmpleado.antiguedad, numeroFax);
    }
}
