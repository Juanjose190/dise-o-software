package Ejercicio3;


import javax.swing.JOptionPane;

public class Vendedor extends Empleado {

    private String cocheEmpresa;
    private double porcentajeComision;

    public Vendedor(String nombre, String apellidos, String dni, String direccion, String telefono, double salario, int antiguedad, String cocheEmpresa, double porcentajeComision) {
        super(nombre, apellidos, dni, direccion, telefono, salario, antiguedad);
        this.cocheEmpresa = cocheEmpresa;
        this.porcentajeComision = porcentajeComision;
    }

    @Override
    public void incrementarSalario(double porcentaje) {
        super.incrementarSalario(10);
    }

    @Override
    public void imprimirDatos() {
        super.imprimirDatos();
        JOptionPane.showMessageDialog(null, "Coche de Empresa: " + cocheEmpresa
                + "\nPorcentaje de Comisión: " + porcentajeComision + "%");
    }

    public static Vendedor crearVendedor() {
        Empleado baseEmpleado = Empleado.crearEmpleado();
        String cocheEmpresa = JOptionPane.showInputDialog("Ingrese el coche de la empresa (matrícula, marca, modelo):");
        double porcentajeComision = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el porcentaje de comisión del vendedor:"));
        return new Vendedor(baseEmpleado.nombre, baseEmpleado.apellidos, baseEmpleado.dni,
                baseEmpleado.direccion, baseEmpleado.telefono,
                baseEmpleado.salario, baseEmpleado.antiguedad, cocheEmpresa, porcentajeComision);
    }
}
