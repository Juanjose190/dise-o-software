package Ejercicio3;
import javax.swing.JOptionPane;

public class Empleado {

    protected String nombre; 
    protected String apellidos;
    protected String dni;
    protected String direccion; 
    protected String telefono;
    protected double salario;
    protected int antiguedad;

    public Empleado(String nombre, String apellidos, String dni, String direccion, String telefono, double salario, int antiguedad) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.direccion = direccion;
        this.telefono = telefono;
        this.salario = salario;
        this.antiguedad = antiguedad;
    }

    public void incrementarSalario(double porcentaje) {
        this.salario += salario * porcentaje / 100;
    }

    public void imprimirDatos() {
        JOptionPane.showMessageDialog(null, "Nombre: " + nombre + "\nApellidos: " + apellidos
                + "\nDNI: " + dni + "\nDirección: " + direccion
                + "\nTeléfono: " + telefono + "\nSalario: " + salario
                + "\nAntigüedad: " + antiguedad);
    }

    public static Empleado crearEmpleado() {
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del empleado:");
        String apellidos = JOptionPane.showInputDialog("Ingrese los apellidos del empleado:");
        String dni = JOptionPane.showInputDialog("Ingrese el DNI del empleado:");
        String direccion = JOptionPane.showInputDialog("Ingrese la dirección del empleado:");
        String telefono = JOptionPane.showInputDialog("Ingrese el teléfono del empleado:");
        double salario = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el salario del empleado:"));
        int antiguedad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la antigüedad del empleado en años:"));

        return new Empleado(nombre, apellidos, dni, direccion, telefono, salario, antiguedad);
    }
}
