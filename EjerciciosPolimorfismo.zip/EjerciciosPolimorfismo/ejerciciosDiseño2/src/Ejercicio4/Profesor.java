package Ejercicio4;


public class Profesor extends Empleado {

    private String departamento;

    public Profesor(String nombre, String apellidos, String identificacion, String estadoCivil, int anioIncorporacion, int numeroDespacho, String departamento) {
        super(nombre, apellidos, identificacion, estadoCivil, anioIncorporacion, numeroDespacho);
        this.departamento = departamento;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    @Override
    public void imprimirInformacion() {
        super.imprimirInformacion();
        System.out.println("Departamento: " + departamento);
    }
}
