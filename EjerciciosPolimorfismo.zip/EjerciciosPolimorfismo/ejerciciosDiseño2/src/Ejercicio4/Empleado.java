package Ejercicio4;


public class Empleado extends Persona {

    private int anioIncorporacion;
    private int numeroDespacho;

    public Empleado(String nombre, String apellidos, String identificacion, String estadoCivil, int anioIncorporacion, int numeroDespacho) {
        super(nombre, apellidos, identificacion, estadoCivil);
        this.anioIncorporacion = anioIncorporacion;
        this.numeroDespacho = numeroDespacho;
    }

    public int getAnioIncorporacion() {
        return anioIncorporacion;
    }

    public int getNumeroDespacho() {
        return numeroDespacho;
    }

    public void setNumeroDespacho(int numeroDespacho) {
        this.numeroDespacho = numeroDespacho;
    }

    @Override
    public void imprimirInformacion() {
        super.imprimirInformacion();
        System.out.println("Año de Incorporación: " + anioIncorporacion);
        System.out.println("Número de Despacho: " + numeroDespacho);
    }
}
